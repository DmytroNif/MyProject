//
//  Constants.swift
//  MyProjectApp
//
//  Created by admin on 06/02/2024.
//

import Foundation

struct Constant {
    static var baseURL: String = "https://api.themoviedb.org/3"
    static var apiKey: String = "623a938b661b8e1327da5bbea8403a17"
    static var posterBaseURL = "https://image.tmdb.org/t/p/w500"
}

//
//  DetailsViewController.swift
//  MyProjectApp
//
//  Created by admin on 07/02/2024.
//

import UIKit
import RealmSwift
import ProgressHUD
import YouTubeiOSPlayerHelper
import Lottie

class DetailsViewController: UIViewController {
    let mainView = DetailsView()
    var movieDetails: MovieDetails?
    var movie: Movie?
    var storage = StorageImpl()
    weak var coordinator: MainCoordinator?
    
    var titleText: String?
    
    private var animationView: LottieAnimationView {
            return mainView.animationView
        }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        mainView.saveButton.addTarget(self, action: #selector(addToFavorites), for: .touchUpInside)
 
        
        if let titleText {
            mainView.titleLabel.text = titleText
        }

    }
    
    override func viewWillAppear(_ animated: Bool) {
        // Перевірка, чи фільм збережений
           if let movie = self.movie, storage.isMovieSaved(movieId: movie.id) {
               mainView.saveButton.setImage(UIImage(systemName: "bookmark.fill"), for: .normal)
           } else {
               mainView.saveButton.setImage(UIImage(systemName: "bookmark"), for: .normal)
           }
    }
    
    override func loadView() {
        super.loadView()
        view = mainView
    }
  
    @objc
    func addToFavorites() {
        if let movie = self.movie {
            storage.save(movie: movie) {
                ProgressHUD.liveIcon(icon: .added)
                self.mainView.animationView.play()
                print(movie.title )
            }
        }
        }
    @objc func saveButtonTapped() {
            
        }
}
